"""JARVIS v9 consolidated launcher — Visual Office upgrade for Kichkina Ibrohim.

Preserves bot.py + v2-v8 agents and the working photo Instagram approval.
Adds original short vertical MP4 Reels and Story images with two-stage owner
approval, voice/text commands, /reel, /storypost and /jarvisstatus.

Requires Dockerfile.JARVIS9 (ffmpeg binary), existing bot.py and JARVIS files.
The existing Make.com PHOTO route remains unchanged. Reels and Stories use
SEPARATE webhook events and need their own Make routes before publishing.
No private secrets are embedded. Never auto-publishes a draft.
"""
from __future__ import annotations

import asyncio
import base64
import io
import logging
import os
import re
import secrets
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont, ImageOps
from telegram import CommandHandler, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import NetworkError, TimedOut

import JARVIS_v8_instagram_media_FIX as media

LOG = logging.getLogger("KichkinaIbrohim.JARVIS9")
REEL_EVENT = "instagram_reel_approved"
STORY_EVENT = "instagram_story_approved"
MAX_VIDEO_BYTES = 18_000_000
REEL_LENGTH_SECONDS = 12
FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

REEL_INTENT = re.compile(r"(?i)(?:\breels?\b|\breel\b|рилс|рилз|видеоролик|видео\s*ролик|видео[ -]?пост|video\s*post|видео\s*тайёр|видео\s*ярат)")
STORY_INTENT = re.compile(r"(?i)(?:сторис|стори(?:й|я)|story|stories|ҳикоя|хикоя)")
STORY_PUBLISH = re.compile(r"(?i)(?:тайёрла|ярат|ясаб|қил|кил|ч[иi]қар|юкла|жойла|публикуй|опубликуй|созда|подготов|post|publish|make|create)")
TRIGGER_CONTEXT = re.compile(r"(?i)(?:инстаграм|instagram|insta|пост|видео|рилс|reels|story|stories|сторис)")


def _owner_only(legacy: Any, update: Any) -> bool:
    return bool(legacy._is_owner(update) and update.effective_chat.type == "private")


def _topic(text: str) -> str:
    """Remove opt-in wake phrases and obvious Instagram command headers."""
    from JARVIS_v8_launcher import v2
    cleaned = v2.strip_wake_word(text or "")
    val = (cleaned if cleaned is not None else text or "").strip()
    val = re.sub(r"(?i)^\s*(?:(?:агент|agent)\s+)?(?:инстаграм|instagram|insta)\s*[:\-—]\s*", "", val)
    val = re.sub(r"(?i)^\s*(?:reels?|рилс|рилз|сторис|стори|stories|story|видеоролик|видео\s*ролик)\s*[:\-—]?\s*", "", val)
    val = re.sub(r"(?i)^\s*(?:(?:тайёрла|ярат|ясаб\s*бер|қил|кил|создай|сделай|prepare|create)\s*[:\-—]?\s*)+", "", val)
    return val[:2000].strip(" :\n\t") or "Илҳом ва янги ғоялар"


def _approval_buttons(label: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(label, callback_data="ig:approve"),
        InlineKeyboardButton("❌ Бекор қилиш", callback_data="ig:reject"),
    ]])


def _draw_text_card(img: Image.Image, title: str, bottom: str, number: int) -> Image.Image:
    frame = ImageOps.fit(img, (720, 1280), method=Image.Resampling.LANCZOS).convert("RGB")
    shade = Image.new("RGBA", frame.size, (0, 0, 0, 0))
    layer = ImageDraw.Draw(shade)
    for y in range(550, 1280):
        # Dark gradient makes Cyrillic and Latin text readable on any image.
        alpha = min(205, int((y - 550) / 730 * 205))
        layer.line([(0, y), (719, y)], fill=(8, 15, 28, alpha))
    frame = Image.alpha_composite(frame.convert("RGBA"), shade)
    draw = ImageDraw.Draw(frame)
    headline_font = ImageFont.truetype(FONT_PATH, 45)
    body_font = ImageFont.truetype(FONT_PATH, 26)
    max_w = 620
    words = re.sub(r"\s+", " ", title).strip().split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        cand = (current + " " + word).strip()
        if draw.textbbox((0, 0), cand, font=headline_font)[2] <= max_w:
            current = cand
        else:
            if current:
                lines.append(current)
            current = word
        if len(lines) >= 3:
            break
    if current and len(lines) < 4:
        lines.append(current)
    lines = lines[:4] or ["JARVIS"]
    y = max(755, 1030 - 62 * len(lines))
    for line in lines:
        # anchor middle avoids misalignment between languages.
        draw.text((360, y), line, fill="white", font=headline_font, anchor="mt", stroke_width=1, stroke_fill=(0, 0, 0))
        y += 62
    draw.rounded_rectangle((42, 1150, 678, 1212), radius=18, fill=(10, 20, 36, 190))
    draw.text((360, 1180), f"{number}/3  ·  {bottom[:42]}", fill=(224, 235, 244), font=body_font, anchor="mm")
    return frame.convert("RGB")


def build_reel_mp4(photo_jpeg: bytes, topic: str, caption: str, narration_mp3: bytes | None) -> bytes:
    """Create an original animated 12 s 9:16 MP4; no copyrighted music.

    Uses three text-card scenes, subtle Ken Burns zoom, H264 and AAC 48kHz.
    Executed in a worker thread to avoid blocking Telegram polling.
    """
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not installed; deploy using Dockerfile.JARVIS9")
    with Image.open(io.BytesIO(photo_jpeg)) as original:
        source = original.convert("RGB")
    raw = re.sub(r"(?s)#[\w_]+", "", caption).replace("\n", " ").strip()
    fragments = [x.strip(" :—–\t") for x in re.split(r"[.!?。]+", raw) if x.strip(" :—–\t")]
    second = next((v for v in fragments if v.casefold() not in topic.casefold() and len(v) > 12), raw[:95])
    if re.search(r"[а-яё]", topic.lower()) and not re.search(r"[қўғҳ]", topic.lower()):
        ending = "Подробнее — в описании"
    elif re.search(r"[a-z]", topic.lower()) and not re.search(r"[а-яёқўғҳ]", topic.lower()):
        ending = "Batafsil — izohda"
    else:
        ending = "Батафсил — изоҳда"
    titles = [topic[:92], second[:95], ending]
    with tempfile.TemporaryDirectory(prefix="jarvis_reel_") as td:
        root = Path(td)
        for i, title in enumerate(titles, start=1):
            card = _draw_text_card(source, title, "JARVIS · Original", i)
            card.save(root / f"slide{i}.jpg", quality=89, optimize=True)
        args = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y"]
        for i in range(1, 4):
            args += ["-loop", "1", "-framerate", "24", "-t", "4", "-i", str(root / f"slide{i}.jpg")]
        if narration_mp3:
            (root / "voice.mp3").write_bytes(narration_mp3)
            args += ["-i", str(root / "voice.mp3")]
            audio_i = 3
        else:
            args += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo"]
            audio_i = 3
        video_filters = []
        for i in range(3):
            video_filters.append(
                f"[{i}:v]scale=864:1536,"
                "zoompan=z='min(zoom+0.001,1.12)':d=1:s=720x1280:fps=24,"
                f"trim=duration=4,setpts=PTS-STARTPTS,format=yuv420p[v{i}]"
            )
        video_filters.append("[v0][v1][v2]concat=n=3:v=1:a=0[v]")
        args += [
            "-filter_complex", ";".join(video_filters),
            "-map", "[v]", "-map", f"{audio_i}:a:0",
            "-t", str(REEL_LENGTH_SECONDS),
            "-r", "24", "-c:v", "libx264", "-preset", "veryfast", "-crf", "27",
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "48000", "-b:a", "96k",
            "-af", f"apad=pad_dur={REEL_LENGTH_SECONDS}",
            "-movflags", "+faststart", "-max_muxing_queue_size", "512",
            str(root / "jarvis_reel.mp4"),
        ]
        result = subprocess.run(args, capture_output=True, text=True, timeout=210, check=False)
        if result.returncode != 0:
            LOG.error("ffmpeg reel encode failed: %s", result.stderr[-450:])
            raise RuntimeError("FFmpeg could not encode Reel")
        encoded = (root / "jarvis_reel.mp4").read_bytes()
        if not (1000 < len(encoded) <= MAX_VIDEO_BYTES) or b"ftyp" not in encoded[:32]:
            raise RuntimeError("Reel MP4 format/size invalid")
        return encoded


async def _vertical_image(legacy: Any, topic: str, caption: str) -> bytes:
    prompt = (
        "Create an original premium vertical Instagram visual, cinematic and "
        "photorealistic or elegantly illustrated, 9:16 composition, with an "
        "uncluttered central subject. No letters, subtitles, logos or watermark. "
        "Do not portray recognizable real people unless specifically requested. "
        "Subject and atmosphere: " + (topic + ". " + caption[:550])[:1400]
    )
    result = await asyncio.wait_for(
        legacy.AI.images.generate(
            model=os.getenv("INSTAGRAM_IMAGE_MODEL", "gpt-image-1-mini"),
            prompt=prompt, size="1024x1536", n=1,
        ), timeout=180,
    )
    if not result.data or not getattr(result.data[0], "b64_json", None):
        raise ValueError("Image model gave no image")
    decoded = base64.b64decode(result.data[0].b64_json, validate=True)
    if len(decoded) > 20_000_000:
        raise ValueError("Generated vertical image too large")
    with Image.open(io.BytesIO(decoded)) as original:
        picture = ImageOps.fit(original.convert("RGB"), (720, 1280), method=Image.Resampling.LANCZOS)
        out = io.BytesIO()
        picture.save(out, format="JPEG", quality=87, optimize=True)
    if len(out.getvalue()) > 7_500_000:
        raise ValueError("Story JPEG too large")
    return out.getvalue()


def render_story_card(jpeg: bytes, topic: str, caption: str) -> bytes:
    """Story captions are not displayed by Instagram; bake text into the JPEG."""
    with Image.open(io.BytesIO(jpeg)) as raw:
        frame = ImageOps.fit(raw.convert("RGB"), (720, 1280), method=Image.Resampling.LANCZOS)
    overlay = Image.new("RGBA", frame.size, (0, 0, 0, 0))
    dr = ImageDraw.Draw(overlay)
    for y in range(580, 1280):
        dr.line([(0, y), (719, y)], fill=(7, 13, 27, min(218, int((y - 580) * 218 / 700))))
    blended = Image.alpha_composite(frame.convert("RGBA"), overlay)
    dr = ImageDraw.Draw(blended)
    font = ImageFont.truetype(FONT_PATH, 49)
    small = ImageFont.truetype(FONT_PATH, 29)
    headline = re.sub(r"\s+", " ", topic).strip()[:95] or "Янги ғоялар"
    pieces = []
    row = ""
    for w in headline.split(" "):
        candidate = (row + " " + w).strip()
        if dr.textbbox((0, 0), candidate, font=font)[2] <= 625:
            row = candidate
        else:
            if row:
                pieces.append(row)
            row = w
    if row:
        pieces.append(row)
    for i, line in enumerate(pieces[:4]):
        dr.text((360, 824 + i * 66), line, font=font, anchor="mm", fill="white", stroke_width=1, stroke_fill="#101820")
    snippet = re.split(r"[.!?\n]", re.sub(r"#[^\s]+", "", caption).strip())[0].strip()[:65]
    if snippet:
        dr.text((360, 1145), snippet, font=small, anchor="mm", fill="#edf4f9")
    out = io.BytesIO()
    blended.convert("RGB").save(out, format="JPEG", quality=88, optimize=True)
    if len(out.getvalue()) > 7_500_000:
        raise ValueError("Story preview larger than Meta JPEG limit")
    return out.getvalue()


async def _narration(legacy: Any, caption: str) -> bytes | None:
    if os.getenv("JARVIS_REEL_VOICE", "1").strip().lower() in ("0", "false", "off"):
        return None
    words = re.sub(r"[#@][^\s]+", "", caption)
    words = re.sub(r"[\r\n]+", ". ", words).strip()[:145]
    if not words:
        return None
    try:
        response = await asyncio.wait_for(
            legacy.AI.audio.speech.create(
                model=os.getenv("JARVIS_TTS_MODEL", "gpt-4o-mini-tts"),
                voice=os.getenv("JARVIS_TTS_VOICE", "nova"),
                input=words, response_format="mp3",
            ), timeout=55,
        )
        audio = response.content
        if not isinstance(audio, (bytes, bytearray)) or len(audio) > 7_000_000:
            raise ValueError("invalid TTS audio")
        return bytes(audio)
    except Exception as exc:
        # A silent AAC Reel is a better fallback than blocking the entire job.
        LOG.warning("Reel voice synthesis unavailable (%s)", type(exc).__name__)
        return None


def github_upload_mp4(video: bytes, token: str, repo: str) -> str:
    """Only public media branch; mirrors the existing proven JPEG uploader."""
    if not token or len(token) < 12:
        raise RuntimeError("GITHUB_TOKEN is missing")
    repo = media.valid_repo(repo)
    if not (1000 < len(video) <= MAX_VIDEO_BYTES) or b"ftyp" not in video[:32]:
        raise ValueError("Invalid or oversized MP4")
    stamp = datetime.now(timezone.utc).strftime("jarvis-%Y%m%dT%H%M%S-")
    path = "instagram_media/" + stamp + secrets.token_hex(6) + ".mp4"
    media._ensure_media_branch(token, repo)
    result = media._github_request(
        f"{media.GITHUB_API}/repos/{repo}/contents/{path}", token, method="PUT",
        payload={
            "message": "Add owner-approved JARVIS Reel MP4",
            "content": base64.b64encode(video).decode("ascii"),
            "branch": media.MEDIA_BRANCH,
        },
    )
    sha = ((result.get("commit") or {}).get("sha") or "").strip()
    if not re.fullmatch(r"[0-9a-fA-F]{40}", sha):
        raise RuntimeError("GitHub did not return commit SHA")
    return f"{media.GITHUB_RAW}/{repo}/{sha}/{path}"


def _reel_request(text: str) -> bool:
    return bool(REEL_INTENT.search(text)) and not re.search(r"(?i)(контент.?режа|контент.?план|календар|ҳисобот|хисобот|отчёт|анализ|analytics|статистик)", text)


def _story_request(text: str) -> bool:
    return bool(STORY_INTENT.search(text) and STORY_PUBLISH.search(text)) and not re.search(
        r"(?i)(сони|статистик|нечта|сколько|count|insights|ҳисобот|хисобот|report)", text
    )


async def send_media_preview(update: Any, state: dict[str, Any]) -> bool:
    """Only set shown=True after Telegram confirms send, not after generation."""
    state["shown"] = False
    for attempt in range(2):
        try:
            if state["mode"] == "reel":
                video = io.BytesIO(state["video"])
                video.name = "JARVIS_Reel_preview.mp4"
                await update.effective_message.reply_video(
                    video=video, supports_streaming=True,
                    caption="🎬 Reels видеоси тайёр. Фақат видеони кўриб маъқулласангиз, тасдиқланг.",
                    reply_markup=_approval_buttons("✅ Reel'ни Instagram'га юбориш"),
                    read_timeout=120, write_timeout=120, connect_timeout=35, pool_timeout=35,
                )
            else:
                picture = io.BytesIO(state["image"])
                picture.name = "JARVIS_story_preview.jpg"
                await update.effective_message.reply_photo(
                    photo=picture,
                    caption="📲 Story расми тайёр. Тасдиқласангиз Make.com'га жўнатилади.",
                    reply_markup=_approval_buttons("✅ Story'ни Instagram'га юбориш"),
                    read_timeout=90, write_timeout=90, connect_timeout=30, pool_timeout=30,
                )
            state["shown"] = True
            return True
        except (TimedOut, NetworkError) as exc:
            LOG.warning("v9 Telegram preview failed: %s (%d/2)", type(exc).__name__, attempt + 1)
            if attempt == 0:
                await asyncio.sleep(2)
    await update.effective_message.reply_text(
        "⚠️ Медиа тайёр, лекин Telegram'га юбориш кечикди. Instagram'га жўнатилмади.",
        reply_markup=_approval_buttons("🔄 Медиани қайта кўрсатиш"),
    )
    return False


def install(legacy: Any) -> None:
    """Layer v9 after the working v8 photo/Office/voice pipeline."""
    media.install(legacy)
    old_dispatch = legacy.dispatch_user_text
    old_instagram_post = legacy.instagram_post_command
    old_approval = legacy.instagram_approval
    old_post_init = legacy.post_init

    async def reset_photo_post(update, context, topic=None):
        # A new photo draft cancels any stale Story/Reel before the old handler.
        context.user_data.pop("jarvis_v9_media", None)
        return await old_instagram_post(update, context, topic=topic)

    legacy.instagram_post_command = reset_photo_post

    async def request_media(update, context, text: str, mode: str) -> None:
        if not _owner_only(legacy, update):
            await update.effective_message.reply_text("🔐 Бу функция фақат бот эгасининг шахсий чатида ишлайди.")
            return
        subject = _topic(text)
        context.user_data.pop("jarvis_v9_media", None)
        media._clear(context)
        try:
            response = await asyncio.wait_for(
                legacy.AI.responses.create(
                    model=legacy.MODEL,
                    instructions=(
                        "Write one engaging Instagram caption in the language of the user's topic "
                        "for a Reel or Story. Concise, suitable hashtags, no invented factual "
                        "claims, no real people portrayed unless requested. Under 1900 characters."
                    ),
                    input=subject,
                ), timeout=80,
            )
            draft = (response.output_text or "").strip()[:2200]
            if not draft:
                raise ValueError("empty caption")
        except Exception as exc:
            LOG.warning("v9 caption draft failed (%s)", type(exc).__name__)
            await update.effective_message.reply_text("⚠️ Матн тайёрлаб бўлмади. Қайта синаб кўр.")
            return
        context.user_data["instagram_draft"] = draft
        context.user_data["jarvis_v9_media"] = {
            "mode": mode, "topic": subject, "caption": draft,
            "shown": False, "ready": False,
        }
        await update.effective_message.reply_text(
            ("🎬 Reel" if mode == "reel" else "📲 Story") +
            " лойиҳаси:\n\n" + draft +
            "\n\nБиринчи тасдиқлаш медиани яратади. "
            "Иккинчи тасдиқлашгина GitHub ва Make.com'га жўнатади.",
            reply_markup=_approval_buttons("✅ Медиани тайёрлаш"),
        )

    async def media_dispatch(update, context, text):
        # Test full original phrase: _topic intentionally strips "рилс"/"сторис".
        if _reel_request(text):
            return await request_media(update, context, text, "reel")
        if _story_request(text) and TRIGGER_CONTEXT.search(text):
            return await request_media(update, context, text, "story")
        return await old_dispatch(update, context, text)

    async def approved_media(update, context):
        state = context.user_data.get("jarvis_v9_media")
        if not isinstance(state, dict):
            return await old_approval(update, context)
        query = update.callback_query
        await query.answer()
        if not _owner_only(legacy, update):
            await query.message.reply_text("🔐 Бу амал фақат бот эгаси учун.")
            return
        if context.user_data.get("jarvis_v9_busy"):
            await query.message.reply_text("⏳ Аввалги топшириқ тугашини кутинг.")
            return
        if query.data == "ig:reject":
            context.user_data.pop("jarvis_v9_media", None)
            media._clear(context)
            await query.edit_message_reply_markup(reply_markup=None)
            await query.message.reply_text("❌ Reel/Story лойиҳаси бекор қилинди.")
            return
        if query.data != "ig:approve":
            return await old_approval(update, context)
        context.user_data["jarvis_v9_busy"] = True
        try:
            if not state.get("ready"):
                await query.edit_message_reply_markup(reply_markup=None)
                await query.message.reply_text("🎨 AI медиа тайёрлаяпти. Ҳали Instagram'га ҳеч нарса чиқмайди...")
                try:
                    image = await _vertical_image(legacy, state["topic"], state["caption"])
                    if state["mode"] == "reel":
                        speech = await _narration(legacy, state["caption"])
                        state["video"] = await asyncio.to_thread(
                            build_reel_mp4, image, state["topic"], state["caption"], speech,
                        )
                    else:
                        state["image"] = await asyncio.to_thread(
                            render_story_card, image, state["topic"], state["caption"],
                        )
                    state["ready"] = True
                except Exception as exc:
                    LOG.exception("v9 %s render failed (%s)", state["mode"], type(exc).__name__)
                    await query.message.reply_text(
                        "⚠️ Медиа яратиб бўлмади. Жорий лойиҳа сақланди, қайта уриниб кўринг.",
                        reply_markup=_approval_buttons("🔄 Қайта тайёрлаш"),
                    )
                    return
                await send_media_preview(update, state)
                return
            if not state.get("shown"):
                await query.edit_message_reply_markup(reply_markup=None)
                await send_media_preview(update, state)
                return
            # Only the user's second confirmation reaches external services.
            await query.edit_message_reply_markup(reply_markup=None)
            await query.message.reply_text("⏳ Тасдиқланган медиа GitHub/Make.com'га юбориляпти...")
            stage = "github"
            token = (os.getenv("GITHUB_TOKEN") or "").strip()
            repo = media.valid_repo(os.getenv("GITHUB_MEDIA_REPO", media.DEFAULT_REPO))
            webhook = media.validate_webhook(os.getenv("MAKE_WEBHOOK_URL", ""))
            public_url = state.get("public_url")
            if not public_url:
                if state["mode"] == "reel":
                    public_url = await asyncio.to_thread(github_upload_mp4, state["video"], token, repo)
                else:
                    public_url = await asyncio.to_thread(media.github_upload_jpeg, state["image"], token, repo)
                state["public_url"] = public_url
            stage = "make"
            payload = {
                "event": REEL_EVENT if state["mode"] == "reel" else STORY_EVENT,
                "media_type": "REELS" if state["mode"] == "reel" else "STORIES",
                "caption": state["caption"][:2200],
                "video_url": public_url if state["mode"] == "reel" else None,
                "image_url": public_url if state["mode"] == "story" else None,
                "telegram_user_id": int(update.effective_user.id),
                "approved_at": datetime.now(timezone.utc).isoformat(),
            }
            try:
                await asyncio.to_thread(legacy._send_instagram_webhook, webhook, payload)
            except Exception as exc:
                # Make may have accepted the call even if its HTTP response was lost.
                # Never automatically re-send an ambiguous publish request.
                LOG.warning("v9 Make webhook result uncertain (%s)", type(exc).__name__)
                context.user_data.pop("jarvis_v9_media", None)
                media._clear(context)
                await query.message.reply_text(
                    "⚠️ Make.com'дан аниқ жавоб келмади. Қайта юборилмади: "
                    "такрорий пост чиқиб кетиши мумкин. Make тарихини текширинг."
                )
                return
            context.user_data.pop("jarvis_v9_media", None)
            media._clear(context)
            await query.message.reply_text(
                "✅ Тасдиқланган " + ("Reel MP4" if state["mode"] == "reel" else "Story JPEG") +
                " GitHub'га ва Make.com вебхукига юборилди.\n" + public_url +
                "\n⚠️ Instagram'да эълон қилинганини Make.com сценарийси орқали текширинг."
            )
        except Exception as exc:
            LOG.warning("v9 external approval failed (%s)", type(exc).__name__)
            await query.message.reply_text(
                "⚠️ GitHub'га юклаш ёки конфигурацияда хато. "
                "Railway логларидан аниқ сабабни текшириш мумкин."
                + ("\nҚайта юбориш мумкин." if not state.get("public_url") else ""),
                reply_markup=_approval_buttons("🔄 Қайта уриниш") if not state.get("public_url") else None,
            )
        finally:
            context.user_data["jarvis_v9_busy"] = False

    async def status_command(update, context):
        if not _owner_only(legacy, update):
            await update.effective_message.reply_text("🔐 Фақат бот эгаси.")
            return
        ready = [
            "✅ AI чат, ўзбекча ва русча", "✅ Овозли буйруқ ва овозли жавоб",
            "✅ Word, Excel, PDF, PowerPoint", "✅ Файл ўқиш ва PDF бирлаштириш",
            "✅ Эслатмалар, вазифалар, кирим/чиқим", "✅ Янгиликлар, курслар, веб-қидирув",
            "✅ Instagram расмли пост ва тасдиқлаш",
            "✅ Reels учун MP4 ва Stories расми тайёрлаш",
            "✅ Расмдан замонавий Word/Excel/PPTX/PDF",
            "✅ Расмни AI билан таҳрирлаш, /makeimage, /readimage",
        ]
        deps = []
        deps.append("✅ ffmpeg" if shutil.which("ffmpeg") else "⚠️ ffmpeg йўқ")
        deps.append("✅ GitHub уланган" if os.getenv("GITHUB_TOKEN") else "⚠️ GITHUB_TOKEN йўқ")
        deps.append("✅ Make вебхук уланган" if os.getenv("MAKE_WEBHOOK_URL") else "⚠️ MAKE_WEBHOOK_URL йўқ")
        await update.effective_message.reply_text(
            "🤖 JARVIS v10 — бошқарув панели\n" + "\n".join(ready) +
            "\n\n" + " · ".join(deps) +
            "\n\nБуйруқлар: /reel Мавзу, /storypost Мавзу, /instapost Мавзу."
            "\n⚠️ Reels/Stories эълони учун Make.com'да алоҳида йўналиш талаб қилинади."
        )

    async def reel_command(update, context):
        await request_media(update, context, " ".join(context.args), "reel")

    async def storypost_command(update, context):
        await request_media(update, context, " ".join(context.args), "story")

    async def post_init_v9(app):
        await old_post_init(app)
        # Add only three unique commands; existing routing remains intact.
        app.add_handler(CommandHandler("reel", reel_command))
        app.add_handler(CommandHandler("storypost", storypost_command))
        app.add_handler(CommandHandler("jarvisstatus", status_command))

    legacy.dispatch_user_text = media_dispatch
    legacy.instagram_approval = approved_media
    legacy.post_init = post_init_v9
    install_visual_office(legacy)
    install_creative_ai(legacy)


# ---- JARVIS v9 Visual Office: real edited images + editable documents ----
import json as _v10_json
import time as _v10_time
from xml.sax.saxutils import escape as _v10_escape

_VISUAL_WORD = re.compile(r'(?i)(?:\bword\b|\bdocx\b|ворд|wordga|wordda|хужжат|ҳужжат|hujjat)')
_VISUAL_EXCEL = re.compile(r'(?i)(?:\bexcel\b|\bxlsx\b|excelga|excelda|эксел|жадвал|jadval|таблиц)')
_VISUAL_PPT = re.compile(r'(?i)(?:\bpptx\b|powerpoint|pptga|слайд|slayd|презентац|taqdimot|тақдимот)')
_VISUAL_PDF = re.compile(r'(?i)(?:\bpdf\b|pdfga|pdfda|пдф)')
_VISUAL_EDIT = re.compile(r'(?i)(?:photoshop|фотошоп|фотошоп|foto.?shop|rasmni.{0,35}(?:o.zgartir|tahrirla|bezat|tozala|edit)|расмни.{0,35}(?:таҳрир|узгарт|ўзгарт|безат|тозала)|фонни|background|ретуш|retush|удали фон|remove background)')
_VISUAL_INTENT = re.compile(r'(?i)(?:тайёрла|ярат|қилиб бер|килиб бер|ясаб|тўғирла|тугирла|ўтказ|кўчир|ташлаб бер|сделай|создай|оформи|перенеси|переведи|редактир|генерир|tayyorla|yarat|qilib ber|yasab|tuzib ber|o.tkaz|ko.chir|shakllantir|tashlab ber|tashla|qil|qiling|aylantir|tahrirla|make|create|convert|export|design|edit)')


def _visual_intent(text: str, *, has_picture: bool = False) -> str | None:
    t = (text or '').strip()
    if not t:
        return None
    if has_picture:
        if _VISUAL_EDIT.search(t):
            return 'edit'
        if _VISUAL_WORD.search(t):
            return 'word'
        if _VISUAL_EXCEL.search(t):
            return 'excel'
        if _VISUAL_PPT.search(t):
            return 'ppt'
        if _VISUAL_PDF.search(t):
            return 'pdf'
        return None
    if _VISUAL_EDIT.search(t) and _VISUAL_INTENT.search(t):
        return 'edit'
    if _VISUAL_INTENT.search(t):
        if _VISUAL_WORD.search(t): return 'word'
        if _VISUAL_EXCEL.search(t): return 'excel'
        if _VISUAL_PPT.search(t): return 'ppt'
        if _VISUAL_PDF.search(t): return 'pdf'
    return None


def _v10_photo_clean(data: bytes, max_side: int = 1900, jpeg_quality: int = 88) -> bytes:
    pic = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert('RGB')
    pic.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
    out = io.BytesIO()
    pic.save(out, 'JPEG', quality=jpeg_quality, optimize=True)
    return out.getvalue()


def _v10_heading_color():
    from docx.shared import RGBColor
    return RGBColor(24, 54, 88)


def _v10_style_doc(doc):
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.enum.style import WD_STYLE_TYPE
    sect = doc.sections[0]
    sect.top_margin = Inches(0.82); sect.bottom_margin = Inches(.75)
    sect.left_margin = Inches(.86); sect.right_margin = Inches(.83)
    normal = doc.styles['Normal']
    normal.font.name = 'DejaVu Sans'; normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor(48, 62, 76)
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.line_spacing = 1.17
    for key, size in [('Title', 21),('Heading 1', 15),('Heading 2', 12)]:
        st=doc.styles[key]; st.font.name = 'DejaVu Sans'; st.font.size=Pt(size)
        st.font.bold=True; st.font.color.rgb = _v10_heading_color()
        st.paragraph_format.space_before=Pt(13); st.paragraph_format.space_after=Pt(8)
    header = sect.header.paragraphs[0]
    header.text = 'JARVIS  •  OFFICE'
    header.style = doc.styles['Normal']
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for run in header.runs:
        run.bold=True; run.font.size=Pt(8); run.font.color.rgb=RGBColor(20, 122, 142)
    footer=sect.footer.paragraphs[0]
    footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=footer.add_run('—  '); r.font.size=Pt(8)
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'), 'PAGE')
    footer._p.append(fld)
    return doc


def _v10_cell_shade(cell, color='E8F1F7'):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tcPr=cell._tc.get_or_add_tcPr()
    shade=OxmlElement('w:shd'); shade.set(qn('w:fill'), color)
    tcPr.append(shade)


def _v10_safe_text(item: Any, max_chars=10000):
    if isinstance(item,(str,int,float)): return str(item)[:max_chars]
    return ''


def _v9_insert_doc_picture(doc, image_bytes: bytes):
    """Fit the original picture on an A4 page without cropping or clipping."""
    from docx.shared import Inches
    with Image.open(io.BytesIO(image_bytes)) as pic:
        w, h = pic.size
    scale = min(6.55 / max(w, 1), 7.3 / max(h, 1))
    return doc.add_picture(io.BytesIO(image_bytes), width=Inches(w * scale), height=Inches(h * scale))


def _v9_insert_slide_picture(slide, image_bytes: bytes):
    """Fit a photo into the right hand content area; do not stretch or clip it."""
    from pptx.util import Inches
    with Image.open(io.BytesIO(image_bytes)) as pic:
        w, h = pic.size
    scale = min(4.8 / max(w, 1), 4.1 / max(h, 1))
    slide.shapes.add_picture(io.BytesIO(image_bytes), Inches(7.1), Inches(2.0),
                             width=Inches(w * scale), height=Inches(h * scale))


def _v10_make_docx(content: dict, original_image: bytes | None = None, exact_layout=False):
    """Editable text, structured tables and an untouched reference scan on its own page."""
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    doc = _v10_style_doc(Document())
    title=_v10_safe_text(content.get('title') or 'Ҳужжат', 160)
    if exact_layout and original_image:
        cover=doc.add_heading('Асл расмнинг кўриниши',0)
        cover.alignment=WD_ALIGN_PARAGRAPH.CENTER
        # Embedding the unchanged scan gives visual fidelity, though not editability.
        _v9_insert_doc_picture(doc, original_image)
        doc.add_page_break()
        note=doc.add_paragraph('Қуйида расмдан кўчирилган таҳрирланадиган матн. Тузилиш ва имло текширилиши керак.')
        for run in note.runs: run.italic=True; run.font.size=Pt(9)
    h=doc.add_heading(title,0);h.alignment=WD_ALIGN_PARAGRAPH.CENTER
    if content.get('subtitle'):
        p=doc.add_paragraph(_v10_safe_text(content['subtitle'],300));p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for para in (content.get('paragraphs') or [])[:40]:
        if _v10_safe_text(para): doc.add_paragraph(_v10_safe_text(para))
    for sec in (content.get('sections') or [])[:35]:
        if not isinstance(sec,dict): continue
        if sec.get('heading'): doc.add_heading(_v10_safe_text(sec['heading'],160),level=1)
        for para in (sec.get('paragraphs') or [])[:35]:
            if _v10_safe_text(para): doc.add_paragraph(_v10_safe_text(para))
        for item in (sec.get('bullets') or [])[:25]:
            if _v10_safe_text(item):doc.add_paragraph(_v10_safe_text(item),style='List Bullet')
        for t in (sec.get('tables') or [])[:8]:
            if isinstance(t,dict): _v10_add_table(doc,t)
    for t in (content.get('tables') or [])[:15]:
        if isinstance(t,dict): _v10_add_table(doc,t)
    if content.get('notes'):
        doc.add_heading('Изоҳлар',level=2)
        for n in content['notes'][:20]: doc.add_paragraph(_v10_safe_text(n),style='List Bullet')
    if original_image and not exact_layout:
        doc.add_page_break()
        doc.add_heading('Манба расм (асл нусха)',level=1)
        doc.add_paragraph('Расмдан олинган матнда хато бўлиши мумкин; асл нусха таққослаш учун берилди.')
        _v9_insert_doc_picture(doc, original_image)
    output=io.BytesIO();doc.save(output);output.seek(0)
    return output


def _v10_add_table(doc, data: dict):
    from docx.shared import RGBColor, Pt
    headers=[_v10_safe_text(c,200) for c in (data.get('headers') or [])[:12]]
    rows=[r for r in (data.get('rows') or [])[:150] if isinstance(r,list)]
    if not headers and rows:
        headers=[f'{i+1}' for i in range(min(12,len(rows[0])))]
    if not headers:return
    from docx.enum.table import WD_TABLE_ALIGNMENT
    t=doc.add_table(rows=1,cols=len(headers))
    t.style='Table Grid';t.alignment=WD_TABLE_ALIGNMENT.CENTER
    for i,h in enumerate(headers):
        c=t.rows[0].cells[i];c.text=h;_v10_cell_shade(c,'17365D')
        for p in c.paragraphs:
            for run in p.runs:run.bold=True;run.font.color.rgb=RGBColor(255,255,255);run.font.size=Pt(9)
    for ri,values in enumerate(rows):
        row=t.add_row()
        for i,val in enumerate(values[:len(headers)]):
            row.cells[i].text=_v10_safe_text(val,1500)
            if ri%2==1:_v10_cell_shade(row.cells[i],'EEF4FA')
        for c in row.cells:
            for p in c.paragraphs:
                for run in p.runs:run.font.size=Pt(8.5)
    doc.add_paragraph('')


def _v9_modern_pdf(content: dict):
    """A4 PDF report with Cyrillic-friendly typography, clear sections and tables."""
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, KeepTogether
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.colors import HexColor
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from xml.sax.saxutils import escape
    fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    font='Helvetica'
    if os.path.isfile(fontfile):
        font='JARVIS_Cyrillic'
        if font not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(font,fontfile))
    title=ParagraphStyle('V9Title',fontName=font,fontSize=17,leading=24,textColor=HexColor('#17365D'),spaceAfter=15)
    header=ParagraphStyle('V9Header',fontName=font,fontSize=12.5,leading=18,textColor=HexColor('#087C8C'),spaceBefore=17,spaceAfter=9)
    body=ParagraphStyle('V9Body',fontName=font,fontSize=9.5,leading=15,spaceAfter=9,textColor=HexColor('#324355'))
    small=ParagraphStyle('V9Small',parent=body,fontSize=8.5,leading=13)
    th=ParagraphStyle('V9TableHeader',parent=small,textColor=HexColor('#FFFFFF'))
    out=io.BytesIO()
    story=[]
    text=lambda v: escape(_v10_safe_text(v,10000)).replace(chr(10),'<br/>')
    story.append(Paragraph(text(content.get('title') or 'Ҳужжат'),title))
    if content.get('subtitle'):story.append(Paragraph(text(content.get('subtitle')),body))
    def add_table(data):
        cols=[_v10_safe_text(x,400) for x in (data.get('headers') or [])[:8]]
        rows=[r for r in (data.get('rows') or [])[:100] if isinstance(r,list)]
        if not cols and rows:cols=[f'{i+1}' for i in range(min(8,len(rows[0])))]
        if not cols:return
        width=(A4[0]-2*48)/len(cols)
        cells=[[Paragraph(text(x),th) for x in cols]]
        for row in rows:
            cells.append([Paragraph(text(row[i] if i<len(row) else ''),small) for i in range(len(cols))])
        tab=Table(cells,colWidths=[width]*len(cols),repeatRows=1,hAlign='LEFT')
        tab.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,0),HexColor('#17365D')),
            ('TEXTCOLOR',(0,0),(-1,0),HexColor('#FFFFFF')),
            ('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#FFFFFF'),HexColor('#EAF2FA')]),
            ('GRID',(0,0),(-1,-1),0.25,HexColor('#D6E1EA')),
            ('VALIGN',(0,0),(-1,-1),'TOP'),
            ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
            ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
        ]))
        story.extend([Spacer(1,6),tab,Spacer(1,12)])
    for p in (content.get('paragraphs') or [])[:30]:story.append(Paragraph(text(p),body))
    for sec in (content.get('sections') or [])[:35]:
        if not isinstance(sec,dict):continue
        if sec.get('heading'):story.append(Paragraph(text(sec['heading']),header))
        for p in (sec.get('paragraphs') or [])[:30]:story.append(Paragraph(text(p),body))
        for b in (sec.get('bullets') or [])[:25]:story.append(Paragraph('• '+text(b),body))
        for t in (sec.get('tables') or [])[:7]:
            if isinstance(t,dict):add_table(t)
    for t in (content.get('tables') or [])[:12]:
        if isinstance(t,dict):add_table(t)
    if content.get('notes'):
        story.append(Paragraph('Изоҳлар',header))
        for n in content['notes'][:15]:story.append(Paragraph('• '+text(n),small))
    def decorate(canvas,doc):
        canvas.saveState();w,h=A4
        canvas.setStrokeColor(HexColor('#087C8C'));canvas.setLineWidth(2)
        canvas.line(48,h-42,w-48,h-42)
        canvas.setFont(font,8);canvas.setFillColor(HexColor('#798796'))
        canvas.drawRightString(w-48,32,str(doc.page));canvas.restoreState()
    SimpleDocTemplate(out,pagesize=A4,rightMargin=48,leftMargin=48,topMargin=60,bottomMargin=51).build(story,
        onFirstPage=decorate,onLaterPages=decorate)
    out.seek(0);return out


def _v10_modern_ppt(content: dict, original_image: bytes | None = None):
    from pptx import Presentation
    from pptx.util import Inches as SI, Pt as SP
    from pptx.dml.color import RGBColor as SC
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE
    prs=Presentation();prs.slide_width=SI(13.333);prs.slide_height=SI(7.5)
    slides=(content.get('slides') or [])[:24] or [{'title':content.get('title') or 'Тақдимот','bullets':['Матнни киритинг']}]
    for idx,item in enumerate(slides):
        if not isinstance(item,dict): continue
        slide=prs.slides.add_slide(prs.slide_layouts[6])
        slide.background.fill.solid(); slide.background.fill.fore_color.rgb=SC(247,249,252)
        hdr=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,0,0,prs.slide_width,SI(.18))
        hdr.fill.solid();hdr.fill.fore_color.rgb=SC(20,115,139);hdr.line.fill.background()
        title=slide.shapes.add_textbox(SI(.7),SI(.48),SI(11.8),SI(.82))
        p=title.text_frame.paragraphs[0];p.text=_v10_safe_text(item.get('title') or content.get('title') or 'Тақдимот',110)
        p.font.name='DejaVu Sans';p.font.size=SP(27);p.font.bold=True;p.font.color.rgb=SC(24,54,88)
        bar=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,SI(.75),SI(1.55),SI(11.85),SI(5.2))
        bar.fill.solid();bar.fill.fore_color.rgb=SC(255,255,255);bar.line.color.rgb=SC(229,236,243)
        chart=item.get('chart') if isinstance(item.get('chart'),dict) else {}
        cats=chart.get('categories') or [];vals=chart.get('values') or []
        is_chart=bool(cats and len(cats)==len(vals) and all(isinstance(v,(int,float)) and not isinstance(v,bool) for v in vals))
        show_image=bool(original_image and idx==0 and not is_chart)
        width=5.1 if is_chart or show_image else 11
        body=slide.shapes.add_textbox(SI(1.05),SI(1.97),SI(width),SI(4.38))
        tf=body.text_frame;tf.clear();tf.word_wrap=True
        bullets=[_v10_safe_text(v,170) for v in (item.get('bullets') or [])[:7]]
        if not bullets:bullets=['Маълумот киритилмаган']
        for k,bullet in enumerate(bullets):
            p=tf.paragraphs[0] if k==0 else tf.add_paragraph()
            p.text='•  '+bullet;p.font.name='DejaVu Sans';p.font.size=SP(16 if len(bullets)>=6 else 19)
            p.font.color.rgb=SC(42,61,81);p.space_after=SP(14)
        if is_chart:
            data=CategoryChartData();data.categories=[str(c)[:32] for c in cats[:12]]
            data.add_series(_v10_safe_text(chart.get('title') or 'Кўрсаткич',70),[float(x) for x in vals[:12]])
            ch=slide.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED,SI(6.65),SI(2.05),SI(5.45),SI(3.85),data).chart
            ch.has_legend=False
        elif show_image:
            try:_v9_insert_slide_picture(slide, original_image)
            except Exception: LOG.warning('Could not embed photo in PPTX')
        foot=slide.shapes.add_textbox(SI(10.8),SI(7.02),SI(1.7),SI(.28))
        p=foot.text_frame.paragraphs[0];p.text=f'{idx+1} / {len(slides)}'
        p.font.size=SP(11);p.font.color.rgb=SC(106,121,137)
    out=io.BytesIO();prs.save(out);out.seek(0);return out


async def _v10_analyze_image(legacy, image_bytes: bytes, kind: str, task: str) -> dict:
    raw=_v10_photo_clean(image_bytes)
    if kind=='word':
        schema='{"title":"...","subtitle":"...","sections":[{"heading":"...","paragraphs":["..."],"bullets":["..."]}],"tables":[{"headers":["..."],"rows":[["..."]]}],"notes":["..."]}'
    elif kind=='excel':
        schema='{"title":"...","headers":["..."],"rows":[["..."]],"chart":false,"notes":["..."]}'
    else:
        schema='{"title":"...","slides":[{"title":"...","bullets":["..."]}],"notes":["..."]}'
    instruction=(
        'You are reading an uploaded image for an editable official document. '
        'Transcribe visible Uzbek Cyrillic, Uzbek Latin, or Russian text exactly. '
        'Maintain table rows and headings. Never invent any numbers, names, signatures, dates, or labels. '
        'If hard to read, leave blank and note uncertainty. JSON only; no code fences. '
        f'The requested output format: {kind}. User task: {task[:1000]}. Schema: {schema}'
    )
    response=await asyncio.wait_for(legacy.AI.responses.create(
        model=os.getenv('JARVIS_VISION_MODEL',legacy.MODEL),
        input=[{'role':'user','content':[
            {'type':'input_text','text':instruction},
            {'type':'input_image','image_url':'data:image/jpeg;base64,'+base64.b64encode(raw).decode('ascii'),'detail':'high'},
        ]}],max_output_tokens=6500,
    ),timeout=150)
    data=legacy._agent_json((response.output_text or '').strip())
    if not isinstance(data,dict): raise ValueError('Image extraction is not a JSON object')
    return data


async def _v10_edit_image(legacy, image_bytes: bytes, instruction: str) -> bytes:
    original=ImageOps.exif_transpose(Image.open(io.BytesIO(image_bytes))).convert('RGBA')
    original.thumbnail((1600,1600),Image.Resampling.LANCZOS)
    b=io.BytesIO();original.save(b,format='PNG');b.seek(0)
    prompt=(instruction[:1800] + '\nEdit this uploaded image, keeping all other elements intact unless specifically requested. '
            'Preserve any document text, dates and numbers when possible; do not add new facts. '
            'Do not turn a text document into a redesigned poster unless asked.')
    result=await asyncio.wait_for(legacy.AI.images.edit(
        model=os.getenv('JARVIS_IMAGE_EDIT_MODEL','gpt-image-1-mini'),
        image=('photo.png',b,'image/png'),prompt=prompt,size='1024x1024',
    ),timeout=180)
    encoded=getattr(result.data[0],'b64_json',None) if result.data else None
    if not encoded:raise RuntimeError('Image edit API returned no b64_json')
    return _v10_photo_clean(base64.b64decode(encoded),max_side=1400,jpeg_quality=90)


def install_visual_office(legacy: Any) -> None:
    from telegram import CommandHandler
    old_photo=legacy.photo_handler
    old_dispatch=legacy.dispatch_user_text
    old_init=legacy.post_init
    # Improve actual generated documents, not only instructions returned in chat.
    legacy._agent_docx=_v10_make_docx
    legacy._agent_pptx=_v10_modern_ppt
    legacy._agent_pdf=_v9_modern_pdf

    async def run_photo_action(update,context,kind,task=''):
        msg=update.effective_message
        img=context.user_data.get('v10_last_photo')
        if not img or _v10_time.time()-img.get('time',0)>3600:
            await msg.reply_text('📷 Аввал расмни шу чатга юборинг. Кейин Word, Excel, PPTX, PDF ёки таҳрирлаш топшириғини айтинг.')
            return
        raw=img['data']
        await msg.reply_text('⏳ Расмни таҳлил қилиб, ҳақиқий файл тайёрлаяпман...' if kind!='edit' else '🎨 Расмни таҳрирлаяпман...')
        try:
            if kind=='edit':
                jpg=await _v10_edit_image(legacy,raw,task)
                f=io.BytesIO(jpg);f.name='JARVIS_tahrirlangan_rasm.jpg'
                await msg.reply_photo(photo=f,caption='✅ Таҳрирланган расм тайёр. Асли ўзгаришсиз қолди.',read_timeout=90,write_timeout=90,connect_timeout=30)
                context.user_data['v10_edited_photo']=jpg
                return
            if kind=='pdf':
                pic=ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert('RGB')
                # Preserve original proportions, make a clear multi-megabyte PDF only when needed.
                buf=io.BytesIO();pic.save(buf,format='PDF',resolution=150)
                buf.seek(0); name='JARVIS_rasm_asl_korinish.pdf'
            else:
                content=await _v10_analyze_image(legacy,raw,kind,task)
                if kind=='word':
                    # Exact visual appearance is provided as an embedded source page;
                    # editable text is a careful reconstruction, not pixel-perfect.
                    exact=bool(re.search(r'(?i)(xuddi|айнан|худди|exact|как есть|ўзгартирма|uzgartirma|o.zgartirma)',task))
                    buf=_v10_make_docx(content,original_image=raw,exact_layout=exact);name='JARVIS_rasmdan_tahrirlanadigan_Word.docx'
                elif kind=='excel':
                    buf=legacy._agent_xlsx(content);name='JARVIS_rasmdan_Excel.xlsx'
                else:
                    buf=_v10_modern_ppt(content,original_image=raw);name='JARVIS_rasmdan_PowerPoint.pptx'
            await msg.reply_document(document=buf,filename=name,
                caption=('✅ Файл тайёр. Расмдан кўчирилган матнда хатолар бўлиши мумкин — текширинг.' if kind in ('word','excel','ppt') else '✅ Асл расм PDF файлга жойланди.'),
                read_timeout=90,write_timeout=90,connect_timeout=30)
        except Exception as exc:
            LOG.exception('v9 visual-office %s error (%s)',kind,type(exc).__name__)
            await msg.reply_text('⚠️ Файл ёки расмни тайёрлашда хатолик: '+type(exc).__name__+'. Журнални Railway орқали текширамиз.')

    async def photo_v10(update,context):
        msg=update.effective_message
        item=msg.photo[-1]
        if item.file_size and item.file_size>15_000_000:
            await msg.reply_text('⚠️ Расм ҳажми 15 MB дан ошмасин.');return
        try:
            f=await item.get_file()
            data=bytes(await f.download_as_bytearray())
            context.user_data['v10_last_photo']={'data':data,'time':_v10_time.time()}
            context.user_data['agent_photo']=data
            caption=msg.caption or ''
            kind=_visual_intent(caption,has_picture=True)
            if kind:
                await run_photo_action(update,context,kind,caption)
            elif caption and _VISUAL_EDIT.search(caption):
                await msg.reply_text('Расмда айнан нимани ўзгартириш кераклигини ёзинг.')
            elif caption:
                await old_photo(update,context)
            else:
                await msg.reply_text('📷 Расм қабул қилинди. Масалан: «Wordга айлантир», «Excel жадвал қил», «PDF қил», «Photoshop: орқа фонни оқ қил».')
        except Exception as exc:
            LOG.exception('v9 photo handler failed: %s',type(exc).__name__)
            await msg.reply_text('⚠️ Расмни ўқишда хатолик. Қайта юборинг.')

    async def dispatch_v10(update,context,text):
        intent=_visual_intent(text,has_picture=False)
        if not intent and context.user_data.get('v10_last_photo') and _v10_time.time()-context.user_data['v10_last_photo'].get('time',0)<3600:
            if re.fullmatch(r'(?i)\s*(?:word(?:ga|da)?|excel(?:ga|da)?|pdf(?:ga|da)?|ppt(?:ga)?|powerpoint|ворд|эксел|пдф|слайд|slayd)\s*[.!]?\s*',text or ''):
                intent=_visual_intent(text,has_picture=True)
        if intent=='edit':
            if not re.search(r'(?i)(фон|ранг|рангини|добав|ўчир|о.чир|убери|remove|replace|оч|қора|тозал|хира|сифат|асоси|background|белги|матн|text|таҳрир|retouch|retush|ретуш)',text):
                await update.effective_message.reply_text('Расмда нимани ўзгартиришимни аниқ айтинг: фон, ранг, ёзув, объект ёки сифат.')
                return
            return await run_photo_action(update,context,'edit',text)
        has_pic=bool(context.user_data.get('v10_last_photo')) and _v10_time.time()-context.user_data['v10_last_photo'].get('time',0)<3600
        # Photo-focused task is executed on the actual image, not text-only JSON.
        if has_pic and intent in ('word','excel','ppt','pdf') and re.search(r'(?i)(расм|rasm|фото|surat|сурат|шуни|shuni|скрин|screen|image|picture|жадвални|jadvalni|rasmdan|расмдан)',text):
            return await run_photo_action(update,context,intent,text)
        if intent in ('word','excel','ppt','pdf'):
            kind={'word':'docx','excel':'xlsx','ppt':'pptx','pdf':'pdf'}[intent]
            return await legacy.agent_dispatch(update,context,text,force_kind=kind)
        return await old_dispatch(update,context,text)

    async def photo_word_cmd(update,context): return await run_photo_action(update,context,'word',' '.join(context.args) or 'Расмдан Word ҳужжат ясаб бер')
    async def photo_excel_cmd(update,context): return await run_photo_action(update,context,'excel',' '.join(context.args) or 'Расмдан Excel жадвали ясаб бер')
    async def photo_pdf_cmd(update,context): return await run_photo_action(update,context,'pdf',' '.join(context.args) or 'Расмдан PDF ясаб бер')
    async def photo_ppt_cmd(update,context): return await run_photo_action(update,context,'ppt',' '.join(context.args) or 'Расмдан PowerPoint ярат')
    async def photo_edit_cmd(update,context):
        description=' '.join(context.args).strip()
        if not description:
            await update.effective_message.reply_text('Масалан: /imageedit орқа фонни оқ қил ва объектни ўзгартирма');return
        return await run_photo_action(update,context,'edit',description)
    async def office_help(update,context):
        await update.effective_message.reply_text(
            '🤖 JARVIS Visual Office v9\n'
            '/imageword — расмдан Word\n/imageexcel — расмдан Excel\n/imageppt — расмдан PowerPoint\n/imagepdf — расмни PDF\n'
            '/imageedit кўрсатма — Photoshop каби AI таҳрирлаш\n'
            'Расмга изоҳ ёзиб юборсангиз ҳам шу ишларни бажараман.\n'
            'Word/PDF/PPTX/Excel вазифаларини оддий матнда ҳам ёзиш мумкин.\n'
            'Эслатма: расмдан олинган матн 100% хатосиз бўлиши кафолатланмайди.'
        )
    async def post_init_v10(app):
        await old_init(app)
        for name,fn in {
            'imageword':photo_word_cmd,'imageexcel':photo_excel_cmd,'imagepdf':photo_pdf_cmd,
            'imageppt':photo_ppt_cmd,'imageedit':photo_edit_cmd,'visualoffice':office_help,
        }.items():app.add_handler(CommandHandler(name,fn))

    old_document=legacy.document_handler
    async def office_image_document(update,context):
        document=update.effective_message.document
        name=(document.file_name or '').lower()
        if not name.endswith(('.jpg','.jpeg','.png','.webp')):
            return await old_document(update,context)
        if document.file_size and document.file_size>15_000_000:
            await update.effective_message.reply_text('⚠️ Расм файли 15 MB дан кичик бўлсин.')
            return
        try:
            download=await document.get_file()
            raw=bytes(await download.download_as_bytearray())
            # Reject corrupt images / very large decompression bombs before storing.
            with Image.open(io.BytesIO(raw)) as pic:
                if pic.width*pic.height>40_000_000:raise ValueError('Image resolution too large')
                pic.verify()
            context.user_data['v10_last_photo']={'data':raw,'time':_v10_time.time()}
            context.user_data['agent_photo']=raw
            caption=update.effective_message.caption or ''
            kind=_visual_intent(caption,has_picture=True)
            if kind:
                return await run_photo_action(update,context,kind,caption)
            await update.effective_message.reply_text(
                '📷 Расм файл сифатида қабул қилинди. «Шуни Wordга кўчир», «Excel жадвал қилиб бер», '
                '«PDF қил», «Photoshop: фонни оқ қил» ёки «Расмда нима бор?» деб ёзинг.')
        except Exception as exc:
            LOG.exception('JARVIS image document error (%s)',type(exc).__name__)
            await update.effective_message.reply_text('⚠️ Расмни ўқиб бўлмади. JPEG/PNG файл юборинг.')
    legacy.document_handler=office_image_document
    legacy.photo_handler=photo_v10
    legacy.dispatch_user_text=dispatch_v10
    legacy.post_init=post_init_v10
# ---- end JARVIS v9 Visual Office ----



# ---- JARVIS v9 Creative / Conversational AI extension ----
_IMG_CREATE = re.compile(
    r'(?i)(?:(?:расм|rasm|surat|сурат|image|picture|картинк|логотип|logo|poster|постер|афиша|illustration|иллюстрац)'
    r'.{0,70}(?:ярат|чиз|ясаб|тайёрла|тайорла|чизиб|генерир|создай|нарисуй|сделай|generate|create|make|draw|tayyorla|yarat|yasab|chizib|qilib ber)' 
    r'|(?:ярат|ясаб|тайёрла|создай|нарисуй|generate|draw|create|tayyorla|yarat|yasab)'
    r'.{0,70}(?:расм|rasm|surat|сурат|image|picture|картинк|логотип|logo|poster|постер|иллюстрац))'
)
_CURRENT_INFO = re.compile(
    r'(?i)(?:бугунги\s+(?:янгилик|об.ҳаво|курс|нарх)|bugungi\s+(?:yangilik|ob.havo|kurs|narx)|'
    r'сегодняшн(?:ие|яя)\s+(?:новост|погод|курс)|latest\s+(?:news|price)|'
    r'ҳозирги\s+(?:курс|нарх|янгилик)|hozirgi\s+(?:kurs|narx|yangilik)|'
    r'қанча\s+бўлди\s+бугун|2026\s+йилда\s+ким\s+)' 
)
_PHOTO_QUESTION = re.compile(
    r'(?i)(?:расм|rasm|сурат|surat|фото|image|picture|скрин|screen|ёзув|yozuv|ним(?:а|алар)|nima|'
    r'расмдаги|rasmdagi|расмни ўқи|rasmni o.qi)'
)


def _v9_image_creation_requested(text: str) -> bool:
    text = (text or '').strip()
    if not text or re.search(r'(?i)(instagram|инстаграм|рилс|reels|stories|сторис|видеоролик)', text):
        return False  # existing approved Instagram route handles this
    if re.search(r'(?i)(как|how|қандай|qanday|нима|nima|йўл|usul|қоид|метод)', text) and (text.rstrip().endswith('?') or not re.search(r'(?i)(ярат|ясаб|создай|generate|tayyorla|yasab)',text)):
        return False
    return bool(_IMG_CREATE.search(text))


async def _v9_generate_image(legacy: Any, update: Any, instruction: str):
    """Render, rather than merely describe, an AI image the user explicitly requests."""
    msg = update.effective_message
    await msg.reply_text('🎨 Расмни яратяпман. Тайёр бўлгач файлни юбораман...')
    try:
        prompt = (instruction or 'Замонавий, сифатли иллюстрация')[:1800]
        result = await asyncio.wait_for(legacy.AI.images.generate(
            model=os.getenv('JARVIS_IMAGE_GEN_MODEL', 'gpt-image-1-mini'),
            prompt=prompt, size='1024x1024', n=1,
        ), timeout=180)
        if not result.data or not getattr(result.data[0], 'b64_json', None):
            raise ValueError('AI image generation returned no image')
        photo = _v10_photo_clean(base64.b64decode(result.data[0].b64_json), max_side=1500, jpeg_quality=91)
        io_photo=io.BytesIO(photo);io_photo.name='JARVIS_yaratgan_rasm.jpg'
        await msg.reply_photo(photo=io_photo, caption='✅ Расм тайёр. Ўзгартириш керак бўлса, янги топшириқ айтинг.',
                              read_timeout=90,write_timeout=90,connect_timeout=30,pool_timeout=30)
        # Keep it available for subsequent edits and conversions.
        return photo
    except Exception as exc:
        LOG.exception('JARVIS image generation failed (%s)',type(exc).__name__)
        await msg.reply_text('⚠️ Расм яратишда хатолик. OpenAI image API ёки балансини Railway логларида текширамиз.')
        return None


def install_creative_ai(legacy: Any) -> None:
    """Preserve Office/Reels flows; add image generation and photo-aware free chat."""
    from telegram import CommandHandler
    old_dispatch=legacy.dispatch_user_text
    old_init=legacy.post_init
    # The general chat (non-file questions) still uses the configured OpenAI API model.
    # The appended guidance improves actions vs explanations, not model parity with ChatGPT.
    legacy.SYSTEM = str(getattr(legacy,'SYSTEM','')) + (
        '\nТўлиқ, равон ва фойдали жавоб бер. Ишончсиз фактларни тўқима. '
        'Ҳар қандай бажарилган файл, тасвир, ҳисоб-китоб ёки нашрни фақат воқеан амалга ошган бўлса тасдиқла. '
        'Замонавий маълумот талаб қилинса, интернет қидируви зарурлигини айт. '
        'Ўзбек кирилл/лотин ва рус тилларида тўғри ёз. '
        'Ўзингда мавжуд бўлмаган ташқи сервисга кириш ҳуқуқини даъво қилма.'
    )
    async def dispatch_creative(update,context,text):
        if _v9_image_creation_requested(text):
            data=await _v9_generate_image(legacy,update,text)
            if data:
                context.user_data['v10_last_photo']={'data':data,'time':_v10_time.time()}
            return
        photo=context.user_data.get('v10_last_photo')
        if photo and _v10_time.time()-photo.get('time',0)<3600 and _PHOTO_QUESTION.search(text) \
                and not _visual_intent(text,has_picture=True) and not _v9_image_creation_requested(text) \
                and not _VISUAL_EDIT.search(text):
            return await legacy.converse(update,text,image=_v10_photo_clean(photo['data']))
        if _CURRENT_INFO.search(text) and not _visual_intent(text,has_picture=False):
            return await legacy.converse(update,text,search=True)
        return await old_dispatch(update,context,text)
    async def draw_command(update,context):
        prompt=' '.join(context.args).strip()
        if not prompt:
            await update.effective_message.reply_text('Масалан: /makeimage Замонавий Пахтакор тумани иллюстрацияси')
            return
        data=await _v9_generate_image(legacy,update,prompt)
        if data:context.user_data['v10_last_photo']={'data':data,'time':_v10_time.time()}
    async def read_image_command(update,context):
        photo=context.user_data.get('v10_last_photo')
        if not photo:
            await update.effective_message.reply_text('📷 Аввал расм юборинг.')
            return
        await legacy.converse(update,'Расмдаги ёзувларни аниқ кўчир. Ўқиб бўлмаган ёзувларни ўйлаб топма.',
                              image=_v10_photo_clean(photo['data']))
    async def post_init_creative(app):
        await old_init(app)
        app.add_handler(CommandHandler('makeimage',draw_command))
        app.add_handler(CommandHandler('draw',draw_command))
        app.add_handler(CommandHandler('readimage',read_image_command))
    legacy.dispatch_user_text=dispatch_creative
    legacy.post_init=post_init_creative

# ---- end Creative AI extension ----

def main():
    logging.getLogger("httpx").setLevel(logging.WARNING)
    import bot as legacy
    install(legacy)
    legacy.main()


if __name__ == "__main__":
    main()
